import 'package:circlight/Pages/AdminPRequest.dart';
import 'package:circlight/Pages/ListDelegator.dart';
import 'package:circlight/Pages/ListRequest.dart';
import 'package:circlight/Pages/ParentRequest2.dart';
import 'package:circlight/Pages/Pick_up.dart';
import 'package:circlight/Pages/PreviewReqParent.dart';
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

import 'Pages/AnnouncementParent.dart';
import 'Pages/ParentHome.dart';
import 'Pages/featuerd_screen.dart';

class BottomNavBar extends StatefulWidget {
  int index = 30;
  String documentId;
  BottomNavBar({super.key, required this.index, required this.documentId});
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int _page = 0;
  GlobalKey<CurvedNavigationBarState> _bottomNavigationKey = GlobalKey();
  Widget currentScreen = ParentHome();
  var count = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: CurvedNavigationBar(
          key: _bottomNavigationKey,
          index: 4,
          height: 70.0,
          items: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    //     padding: const EdgeInsets.only(right: 50),
                    child: Align(
                  child: Column(children: [
                    Image.asset("assets/images/REQ2.png",
                        width: 20, height: 20, color: Color(0xff0da6c2)),
                  ]),
                )),
                SizedBox(
                  height: 2,
                ),
                Container(
                  //  padding: const EdgeInsets.only(right: 50),
                  child: Text(
                    'الطلبات',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff0da6c2)),
                  ),
                ),

                // Text
                // Column
                SizedBox(
                  height: 3,
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    //     padding: const EdgeInsets.only(right: 50),
                    child: Align(
                  child: Column(children: [
                    Image.asset("assets/images/announ.png",
                        width: 20, height: 20, color: Color(0xff0da6c2)),
                  ]),
                )),
                SizedBox(
                  height: 2,
                ),
                Container(
                  //  padding: const EdgeInsets.only(right: 50),
                  child: Text(
                    'الإعلانات',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff0da6c2)),
                  ),
                ),
                // Text
                // Column

                SizedBox(
                  height: 3,
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    //     padding: const EdgeInsets.only(right: 50),
                    child: Align(
                  child: Column(children: [
                    Image.asset("assets/images/route.png",
                        width: 20, height: 20, color: Color(0xff0da6c2)),
                  ]),
                )),
                SizedBox(
                  height: 2,
                ),
                Container(
                  //  padding: const EdgeInsets.only(right: 50),
                  child: Text(
                    'أستلام الطفل',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff0da6c2)),
                  ),
                ),
                // Text
                // Column
                SizedBox(
                  height: 3,
                ),
              ],
            ),
            Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                  //    padding:
                  //        const EdgeInsets.only(right: 50),
                  child: Align(
                child: Column(children: [
                  Image.asset("assets/images/delegate.png",
                      width: 20, height: 20, color: Color(0xff0da6c2)),
                ]),
              )),
              Container(
                  //  padding: const EdgeInsets.only(right: 5, left: 5),
                  child: Text(
                ' المفوضين',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff0da6c2),
                ),
              )),
              SizedBox(
                height: 3,
              )
            ]),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  //     padding: const EdgeInsets.only(right: 50),

                  child: Column(children: [
                    Image.asset("assets/images/homepage.png",
                        width: 20, height: 20, color: Color(0xff0da6c2)),
                  ]),
                ),
                SizedBox(
                  height: 2,
                ),
                Container(
                  //  padding: const EdgeInsets.only(right: 50),
                  child: Text(
                    'الرئيسية',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff0da6c2)),
                  ),
                )
                // Text
                // Column
              ],
            ),
          ],
          color: Colors.white,
          buttonBackgroundColor: Colors.white,
          backgroundColor: Color.fromARGB(73, 13, 167, 194),
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 300),
          onTap: (index) {
            setState(() {
              if (widget.index != 30 && count == 0) {
                index = widget.index;

                count += 1;
              }
              _page = index;
              switch (index) {
                case 4:
                  currentScreen = ParentHome();
                  break;
                case 3:
                  currentScreen = ListDelegator();
                  break;
                case 2:
                  currentScreen = FeaturedScreenX();
                  break;
                case 1:
                  currentScreen = AnnouncementParent();
                  break;
                case 0:
                  currentScreen = ListRequest2();
                  break;
                case 5:
                  currentScreen = ParentReqq();
                  break;
                case 6:
                  currentScreen = PreviewReqParent(
                    documentId: widget.documentId,
                  );
                  break;
              }
            });
          },
          letIndexChange: (index) => true,
        ),
        body: currentScreen);
  }
}
