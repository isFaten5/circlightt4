import 'package:flutter/material.dart';

const kPrimaryColor = Color.fromRGBO(90, 180, 168, 1);
const kPrimaryLightColor = Color.fromARGB(255, 247, 241, 255);

const double defaultPadding = 16.0;
